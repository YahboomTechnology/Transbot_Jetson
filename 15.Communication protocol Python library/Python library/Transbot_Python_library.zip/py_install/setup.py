from setuptools import find_packages, setup

setup(
    name='Transbot_Lib',
    version='3.2.3',
    author='Yahboom Team',
    packages=find_packages(),
)

# cd py_install
# sudo python3 setup.py install
