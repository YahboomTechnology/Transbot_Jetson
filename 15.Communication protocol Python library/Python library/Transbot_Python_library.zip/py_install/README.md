
# Python 相关库修改记录


## 安装教程

cd py_install

sudo python3 setup.py install

